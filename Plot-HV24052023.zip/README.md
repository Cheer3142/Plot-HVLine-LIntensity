# Plot-HVLine-LIntensity

The script's purpose is to implement the Horizontal and Vertical lines plotting from Maxim DL.
The user can plot the light intensity by determining the (x,y) position.
The script will check the latest update file and plot Horizontal and Vertical lines at the same time.

